import "./ModalWithForm.css";
import { useModalClose } from "../../hooks/useModalClose";

function ModalWithForm({
  children,
  buttonText,
  title,
  isOpen,
  onClose,
  onSubmit,
  name,
  isValid = true,
}) {
  useModalClose(isOpen, onClose);

  return (
    <div className={`modal modal_type_${name} ${isOpen ? "modal_opened" : ""}`}>
      <div className="modal__content">
        <div className="modal__header">
          <h2 className="modal__title">{title}</h2>
          <button
            onClick={onClose}
            type="button"
            className="modal__close"
          ></button>
        </div>
        <form className="modal__form" name={name} onSubmit={onSubmit}>
          {children}
          <button
            className={`modal__submit ${!isValid ? "modal__submit_disabled" : ""}`}
            type="submit"
            disabled={!isValid}
          >
            {buttonText}
          </button>
        </form>
      </div>
    </div>
  );
}

export default ModalWithForm;
